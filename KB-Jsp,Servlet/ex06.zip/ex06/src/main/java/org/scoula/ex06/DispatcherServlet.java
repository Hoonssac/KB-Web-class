package org.scoula.ex06;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServlet;

import org.scoula.ex06.command.Command;

public class DispatcherServlet extends HttpServlet {
	Map<String, Command> getMap; // GET 방식 요청 처리용 커맨드 맵
	Map<String, Command> postMap; // POST 방식 요청 처리용 커맨드 맵

	String prefix = "/views/";
	String suffix = ".jsp";

	public void init() {
		getMap = new HashMap<>();
		postMap = new HashMap<>();
		createMap(getMap, postMap);
		for (String key : postMap.keySet()) {
			System.out.println(key + " " + postMap.get(key));

		}
	}

	protected void createMap(Map<String, Command> getMap, Map<String, Command> postMap) {

	}
}
